<?php

//Variables
$uname = $_POST["username"];
$pword = $_POST["pword"];

//Validating variables
if ($uname == null or $pword == null){
    echo "Both username and password must be entered. ";
    
}else {
    
   //Making a connection
    $host = "localhost";
    $username = "root";
    $password = "root";
    $database_name = "regform";
    
    $conn = new mysqli($host, $username, $password, $database_name);
    
    $sql = "SELECT * FROM `siteusers` WHERE `Password` = '$pword' AND `Username` = '$uname'";
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
   //Checking login information with the database.
    if ($result = mysqli_query($conn, $sql)) {
        echo "<br>";
       
        if ($row = mysqli_fetch_assoc($result)) {
            echo "Welcome " . $row['Username'] . "! Login Successful." . "<br>";
            
        }else {
            echo "Login unsuccessful.  Please check username and password and try again.";
        }
        
    } else {
        echo " Error: Login unsuccessful: " . $sql . "<br>" . $conn->error;
    }
    
}