<?php
function alert_box($message){
    echo "<script>alert($message)</script>";
}