<?php

session_start();
/*
 * Zac Almas
 * 10/18/20
 * This page handles logins
 */


//Variables
$uname = $_POST["username"];
$pword = $_POST["pword"];

//Validating variables
if ($uname == null or $pword == null){
    echo "Both username and password must be entered. ";
    
}else {
    
   //Making a connection
    $host = "localhost";
    $username = "root";
    $password = "root";
    $database_name = "regform";
    
    $conn = new mysqli($host, $username, $password, $database_name);
    
    $sql = "SELECT * FROM `siteusers` WHERE `Password` = '$pword' AND `Username` = '$uname'";
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
   //Checking login information with the database.
   
    if ($result = mysqli_query($conn, $sql)) {
        echo "<br>";
       
        if ($row = mysqli_fetch_assoc($result)) {
            
            $_SESSION['username']=$row['Username'];
            $_SESSION['id']=$row['ID'];
            echo "Welcome " . $row['Username'] . "! Login Successful." . "<br>";
            
            header("Location: loginSuccess.php");
        }else {
            header("Location: loginPage.php");
            
        }
        
    } else {
        echo " Error: Login unsuccessful: " . $sql . "<br>" . $conn->error;
    }
    
}