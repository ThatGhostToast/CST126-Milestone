<?php
$name = $_GET["name"];
echo "Welcome " . $name . "!" . "</br>";

//Retrieving the variables
$email = $_GET["email"];
$bday = $_GET["birthday"];
$pword = $_GET["password"];
$uname = $_GET["username"];

//connecting to the database
$host = "localhost";
$username = "root";
$password = "root";
$database_name = "regform";

// Create connection
$conn = new mysqli($host, $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

//Insert data into database
$sql = "INSERT INTO siteusers (`ID`, `Name`, `EMail`, `Birthday`, `Password`, `Username`) VALUES (NULL, '$name', '$email', '$bday', '$pword', '$uname')";

//Checking to make sure it made it to the database
if ($conn->query($sql) === TRUE) {
    echo " You have registered successfully!";
} else {
    echo " Error: " . $sql . "<br>" . $conn->error;
}

?>