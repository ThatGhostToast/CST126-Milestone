<?php

session_start();

/*
 * Zac Almas
 * 10/18/20
 * This processes the new blog post
 */

$blogTitle = $_GET['blogTitle'];
$blogContent = $_GET['blogContent'];
$user_id =  $_SESSION['id'];

$host = "localhost";
$username = "root";
$password = "root";
$database_name = "regform";

$conn = new mysqli($host, $username, $password, $database_name);

$sql = "INSERT INTO `blog_posts` (`id`, `title_table`, `blog_content`, `siteusers_ID`) VALUES (NULL, '$blogTitle', '$blogContent', '$user_id');";

if ($conn) {
    $result = mysqli_query($conn, $sql);
    if ($result)
    {
        include 'newBlogAdded.php';
    }
    else {
        echo "Error in the sql " . mysqli_error($conn);
    }
}

else {
    echo "Error connecting " . mysqli_connect_error();
}