<?php

session_start();

/*
 * DayDump
 * Zac Almas
 * 10/18/20
 * This processes new comments
 */

//This allows us to call the function that connects to the database
include 'funcs.php';

$comment = $_GET['comments'];
$blogId = $_GET['id'];
$user_id =  $_SESSION['id'];

$sql = "INSERT INTO `comments_table` (`id`, `comment_text`, `blog_posts_id`, `siteusers_ID`) VALUES (NULL, '$comment', '$blogId', '$user_id');";

if (dbConnect()) {
    $result = mysqli_query(dbConnect(), $sql);
    if ($result)
    {
        include 'newBlogAdded.php';
    }
    else {
        echo "Error in the sql " . mysqli_error(dbConnect());
    }
}

else {
    echo "Error connecting " . mysqli_connect_error();
}
