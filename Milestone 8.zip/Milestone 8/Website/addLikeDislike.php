<?php
session_start();

/*
 * DayDump
 * Zac Almas
 * 10/18/20
 * This processes new likes and dislikes
 */

//This allows us to call the function that connects to the database
include 'funcs.php';

$like = $_GET['like'];
$dislike = $_GET['dislike'];
$blogId = $_GET['id'];
$user_id =  $_SESSION['id'];

//If the users likes the post
if ($like == 1)
{
    $sql_like = "INSERT INTO `likes_dislikes` (`id`, `likes`, `dislikes`, `blog_posts_id`, `siteusers_ID`) VALUES (NULL, '1', NULL, '$blogId', '$user_id');";
    if(dbConnect())
    {
        $res_like = mysqli_query(dbConnect(), $sql_like);
        if($res_like)
        {
            header("Location: http://localhost/Website/loginSuccess.php");
        }
    }
}

//If the user dislikes the post
if ($dislike == 1)
{
    $sql_dislike = "INSERT INTO `likes_dislikes` (`id`, `likes`, `dislikes`, `blog_posts_id`, `siteusers_ID`) VALUES (NULL, NULL, '1', '$blogId', '$user_id');";
    if(dbConnect())
    {
        $res_dislike = mysqli_query(dbConnect(), $sql_dislike);
        if($res_dislike)
        {
            header("Location: http://localhost/Website/loginSuccess.php");
        }
    }
}