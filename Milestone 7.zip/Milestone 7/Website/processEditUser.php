<?php

session_start();
include 'funcs.php';

/*
 * DayDump
 * Zac Almas
 * 11/18/20
 * This processes the edited user.
 */

//Gets variables from editUserInfo.php so that we can update it in the database
$name = $_GET['name'];
$email = $_GET['email'];
$id = $_GET['id'];
$birthday = $_GET['birthday'];
$password = $_GET['password'];
$username = $_GET['username'];
$updateRole = $_GET['role'];
$role = $_SESSION['role'];

//Connects to the database and makes sure you're an admin before proceding 
if (dbConnect() && $role == "admin") {
    
    //Update SQL statement
    $sql = "UPDATE `siteusers` SET `Name` = '$name', `EMail` = '$email', `Birthday` = '$birthday', `Password` = '$password', `Username` = '$username', `Role` = '$updateRole' WHERE `id` = '$id'";
    
    //If successful will send you to the success page and if failed will show an error
    $result = mysqli_query(dbConnect(), $sql);
    if ($result)
    {
        include 'userUpdated.php';
    }
    else {
        echo "Error in the sql " . mysqli_error(dbConnect());
    }
}

else {
    echo "Error connecting " . mysqli_connect_error();
}
