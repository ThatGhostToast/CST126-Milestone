<?php
session_start();

/*
 * Zac Almas
 * 10/18/20
 * This page logs out the user
 */

$_SESSION = array();

session_destroy();
echo "You have logged out.  Have a good one!";

?>