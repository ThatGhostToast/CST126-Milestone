<?php
session_start();

/*
 * DayDump
 * Zac Almas
 * 10/18/20
 * This page allows the admin to alter user posts.
 */

//Allows us to call the function that connects us to the database
require_once 'funcs.php';

//Makes sure the user is an admin
if ($_SESSION['role'] != 'admin')
{
    echo "Please log in as an admin.";
    exit;
}

//Grabs all of the blog posts
$sql = "SELECT * FROM `blog_posts`";

if (dbConnect()) {
    $result = mysqli_query(dbConnect(), $sql);
    if ($result)
    {
        while ($row = mysqli_fetch_assoc($result))
        {
            echo "Blog ID: " . $row['id'] . "<br>";
            echo "Blog title: " . $row['title_table'] . "<br>";
            echo "Blog content: " . $row['blog_content'] . "<br>";
?>
<head>
	<!--Linking the css file to make the website look good  -->
	<link href="makeup.css" rel="stylesheet" type="text/css">
	<style>
	   body {
		  		background: radial-gradient(circle, white, #ECECEC);
		  		font-family:Trebuchet MS;
		  }
	
	   h1 {
		  		 font: bold 50px "Century Schoolbook", Georgia, Times, serif;
				 color: #9370DB;
				 line-height: 90%;
				 margin: .2em 0 .4em 0;
				 letter-spacing: -2px;
				 text-align: center;	
		  }
		
	   h2 {
				 font: bold 25px "Century Schoolbook", Georgia, Times, serif;
				 color: #9370DB;
				 line-height: 90%;
				 margin: .2em 0 .4em 0;
				 letter-spacing: -2px;
				 text-align: center;
				 
		  }
		  
		/*
		   CSS used for the buttons was taken from https://fdossena.com/?p=html5cool/buttons/i.frag
		   */
		   
	   button {
	            display:inline-block;
				padding:0.3em 1.2em;
				margin:0 0.3em 0.3em 0;
				border-radius:2em;
				box-sizing: border-box;
				text-decoration:none;
				font-family:'Roboto',sans-serif;
				font-weight:300;
				background-color:#9370DB;
				text-align:center;
				transition: all 0.2s;
	     }
	     
	   button:hover {
	     		background-color:#4095c6;
	     }
	     
	     body {
	  			
		  		background: radial-gradient(circle, white, #ECECEC);
		  		font-family:Trebuchet MS;
		   }
	     				  
	</style>
</head>
<!-- Buttons that redirect you to the main page and gets users. -->
   	  <a href="loginSuccess.php" class="button1">Return</a>
   	  <a href="getUsers.php" class="button3">Get Users</a>

<!-- Button to delete post via the admin page -->
<form action="processDeletePost.php">
	<input type="hidden" name="id" value="<?php echo $row['id'];?>"></input>
	<button type="submit">Delete</button>
</form>     

<!-- Button to edit blog posts via the admin page -->
<form action="editBlogPost.php">
	<input type="hidden" name="id" value="<?php echo $row['id'];?>"></input>
	<button class="button2" type="submit">Edit</button>
</form>       
            
<?php 
            echo "-----------------------------------------<br>";
            
        }
    } else {
        echo "Error with the sql " . mysqli_error(dbConnect());
    }
}else {
    echo "Error connecting " . mysqli_connect_error();
}
            
?>
    