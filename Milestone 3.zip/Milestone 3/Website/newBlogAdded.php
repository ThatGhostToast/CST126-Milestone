<?php
session_start();
/*
 * Zac Almas
 * 10/18/20
 * This page lets the user know the blog was uploaded successfully
 */
?>

<!DOCTYPE HTML>
<html>
  <head>
   <meta charset="UTF-8">
	<title>Welcome Page</title>
	 <!--Linking the css file to make the website look good  -->
	 <link href="makeup.css" rel="stylesheet" type="text/css">
	 
	 <style>
	   
	 </style>
	  
   </head>
   <body>
   	  <h1>New post added!</h1>
   	  <h2>Click here to return</h2>
   	  
   	  <!-- Buttons -->
   	  <a href="registration.html" class="button1">Register</a>
   	  <a href="logout.php" class="button2">Logout</a>
   	  <a href="loginSuccess.php" class="button3">Return</a>
   	  
   </body>
</html>