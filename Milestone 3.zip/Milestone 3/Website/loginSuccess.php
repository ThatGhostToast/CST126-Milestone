<?php
session_start();

/*
 * Zac Almas
 * 10/18/20
 * Once you have successfully logged in it will send you to this page here
 */
$host = "localhost";
$username = "root";
$password = "root";
$database_name = "regform";

$conn = new mysqli($host, $username, $password, $database_name);

$sql = "SELECT * FROM `blog_posts`";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($result = mysqli_query($conn, $sql)) {
    if($result)
    {
        while($row = mysqli_fetch_assoc($result))
        {
            
            echo "|".$row['title_table'] . "|" . "<br>";
            echo $row['blog_content'] . "<br>";
            echo "--------------------------<br>";
        }
    }
}


?>

<!DOCTYPE HTML>
<html>
  <head>
   <meta charset="UTF-8">
	<title>MainMenu</title>
	 <!--Linking the css file to make the website look good  -->
	 <link href="makeup.css" rel="stylesheet" type="text/css">
	  
   </head>
   <body>
   	  <h1>Welcome <?php echo $_SESSION['username']?>!</h1>
   	  
   	  <!-- Buttons that redirect you to the login page or the registration page. -->
   	  <a href="index.html" class="button1">Menu</a>
   	  <a href="logout.php" class="button2">Logout</a>
   	  <a href="newPost.php" class="button">New</a>
   	  
   </body>
</html>